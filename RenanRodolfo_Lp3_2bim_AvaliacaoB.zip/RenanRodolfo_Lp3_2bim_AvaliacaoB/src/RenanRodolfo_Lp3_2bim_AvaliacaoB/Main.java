package RenanRodolfo_Lp3_2bim_AvaliacaoB;

/**
 *
 * @author Radames/Renan/Rodolfo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new GUIGerador();
    }
}
