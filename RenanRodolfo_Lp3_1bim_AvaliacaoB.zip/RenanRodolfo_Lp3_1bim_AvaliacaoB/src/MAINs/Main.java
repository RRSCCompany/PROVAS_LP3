package MAINs;
 
import GUIs.GUI;
import javax.swing.JFrame;

public class Main { 
   public static void main(JFrame args) {
     GUI gui = new GUI(args);
   }
}
