/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MenuPrincipal;

import GUIs.GUIEquipamento;
import GUIs.GUIPessoa;
import GUIs.GUIApartamento;
import GUIs.GUICliente;
import GUIs.GUIFuncionario;
import GUIs.GUIReserva;
import GUIs.GUISetor;
import GUIs.GUITipoAcomodacao;
import GUIs.GUIAcomodacaoPreco;
import GUIs.GUIPeriodoReserva;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JToolBar;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import tools.Centraliza;
import tools.ManipulaImagem;

class MenuPrincipal extends JFrame {

    private JFrame cp = new JFrame();
    private Point point;
    private JLabel labelComImagemDeTamanhoDiferente = new JLabel();
    private JMenuBar menuBar = new JMenuBar();
    private JMenu menuCadastros = new JMenu("Entidades");
    private JToolBar toolbar = new JToolBar();
    private JButton acomodacao = new JButton("Acomodações");
    private JButton equipamentos = new JButton("Equipamentos");
    private JButton setores = new JButton("Setores");
    private JButton TipoAcomodacao = new JButton("Tipos de Acomodações");
    private JButton pessoa = new JButton("Pessoas");
    private JButton funcionario = new JButton("Funcionários");
    private JButton cliente = new JButton("Clientes");
    private JButton reserva = new JButton("Reservas");
    private JButton PeriodoReserva = new JButton("Período das Reservas");
    private JButton AcomodacaoPreco = new JButton("Preço das Acomodações");
    private JLabel img;
    private JPanel p;

    private ManipulaImagem manipulaimagem = new ManipulaImagem();

    public MenuPrincipal() {

        cp.getContentPane();
        cp.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        cp.setTitle("Menu Principal");
        cp.setSize(1000, 700);
        cp.setLayout(new BorderLayout());
        setLocationRelativeTo(null);//centro do monitor

        Centraliza centraliza = new Centraliza();
        centraliza.centralizaComponente(cp);

//        acomodacao = manipulaimagem.insereBotao(manipulaimagem.criaIcon("../imagenscrud/Acomodacao.png", 80, 80), "Acomodação");
//        equipamentos = manipulaimagem.insereBotao(manipulaimagem.criaIcon("../imagenscrud/equipamento.png", 80, 80), "Equipamentos");
//        setores = manipulaimagem.insereBotao(manipulaimagem.criaIcon("../imagenscrud/setor.png", 80, 80), "Setores");
//        TipoAcomodacao = manipulaimagem.insereBotao(manipulaimagem.criaIcon("../imagenscrud/tipo.png", 80, 80), "Tipo da Acomodação");
//        pessoa = manipulaimagem.insereBotao(manipulaimagem.criaIcon("../imagenscrud/pessoa.png", 80, 80), "Pessoa");
//        funcionario = manipulaimagem.insereBotao(manipulaimagem.criaIcon("../imagenscrud/funcionario_1.png", 80, 80), "Funcionario");
//        cliente = manipulaimagem.insereBotao(manipulaimagem.criaIcon("../imagenscrud/cliente.png", 80, 80), "Cliente");
//        reserva = manipulaimagem.insereBotao(manipulaimagem.criaIcon("../imagenscrud/reserva.png", 80, 80), "Reserva");

        img = new JLabel(manipulaimagem.criaIcon("../imagenscrud/logomenufinal.png", 300, 300));
        toolbar.add(pessoa);
        toolbar.add(cliente);
        toolbar.add(reserva);
        toolbar.add(PeriodoReserva);
        toolbar.add(setores);
        toolbar.add(funcionario);
        toolbar.add(equipamentos);
        toolbar.add(TipoAcomodacao);
        toolbar.add(acomodacao);
        toolbar.add(AcomodacaoPreco);
        toolbar.setBackground(Color.WHITE);

        p = new JPanel();
        p.setLayout(new GridLayout(1, 1));
        p.add(img);
        p.setBackground(Color.WHITE);

        cp.add(toolbar, BorderLayout.NORTH);

        cp.add(p, BorderLayout.CENTER);

        equipamentos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUIEquipamento guiapequipamentos = new GUIEquipamento(cp);
            }
        });
        setores.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUISetor guisetores = new GUISetor(cp);
            }
        });
        TipoAcomodacao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUITipoAcomodacao guiacomodacoes = new GUITipoAcomodacao(cp);
            }
        });
        acomodacao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUIApartamento guiacomodacao = new GUIApartamento(cp);
            }
        });
        pessoa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUIPessoa guipessoa = new GUIPessoa(cp);
            }
        });
        funcionario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUIFuncionario guifuncionario = new GUIFuncionario(cp);
            }
        });
        cliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUICliente guicliente = new GUICliente(cp);
            }
        });
        reserva.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUIReserva guiReserva = new GUIReserva(cp);
            }
        });
        AcomodacaoPreco.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUIAcomodacaoPreco guiAcomodacaoPreco = new GUIAcomodacaoPreco(cp);
            }
        });
        PeriodoReserva.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GUIPeriodoReserva guiPeriodoReserva = new GUIPeriodoReserva(cp);
            }
        });

        cp.setVisible(true);

    }

}
