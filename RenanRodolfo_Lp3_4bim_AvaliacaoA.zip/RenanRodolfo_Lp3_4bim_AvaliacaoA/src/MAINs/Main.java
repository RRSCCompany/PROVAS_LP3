package MAINs;

import GUIs.GUIEquipamento;
import javax.swing.JFrame;

public class Main {

    public static void main(JFrame args) {
        GUIEquipamento gui = new GUIEquipamento(args);
    }
}
