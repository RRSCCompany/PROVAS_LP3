package DAOs;

import static DAOs.DAOGenerico.em;
import Entidades.AcomodacaoPreco;
import Entidades.AcomodacaoPrecoPK;
import Entidades.PeriodoReserva;
import Entidades.PeriodoReservaPK;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DAOPeriodoReserva extends DAOGenerico<PeriodoReserva> {

    public DAOPeriodoReserva() {
        super(PeriodoReserva.class);
    }

    public PeriodoReserva obter(PeriodoReservaPK periodoReservaPk) {
        return em.find(PeriodoReserva.class, periodoReservaPk);
    }

    public List<PeriodoReserva> listInOrderNome() {
        return em.createQuery("SELECT e FROM PeriodoReserva e ORDER BY e.periodoReservaPK.dataReserva").getResultList();
    }

    public List<String> listInOrderNomeStrings() {
        List<PeriodoReserva> lf = listInOrderNome();
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getPeriodoReservaPK().toString());
        }
        return ls;
    }

}
