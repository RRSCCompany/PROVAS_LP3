package DAOs;

import Entidades.AcomodacaoPreco;

public class DAOAcomodacaoPrecoPK extends DAOGenerico<AcomodacaoPreco> {

    public DAOAcomodacaoPrecoPK() {
        super(AcomodacaoPreco.class);
    }
}