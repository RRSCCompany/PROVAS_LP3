package DAOs;

import static DAOs.DAOGenerico.em;
import Entidades.AcomodacaoPreco;
import Entidades.AcomodacaoPrecoPK;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DAOAcomodacaoPreco extends DAOGenerico<AcomodacaoPreco> {

    public DAOAcomodacaoPreco() {
        super(AcomodacaoPreco.class);
    }

    public AcomodacaoPreco obter(AcomodacaoPrecoPK precoProdutoPk) {
        return em.find(AcomodacaoPreco.class, precoProdutoPk);
    }

    public List<AcomodacaoPreco> listInOrderNome() {
        return em.createQuery("SELECT e FROM AcomodacaoPreco e ORDER BY e.preco").getResultList();
    }

    public List<String> listInOrderNomeStrings() {
        List<AcomodacaoPreco> lf = listInOrderNome();
        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getAcomodacaoPrecoPK().toString());
        }
        return ls;
    }

}
