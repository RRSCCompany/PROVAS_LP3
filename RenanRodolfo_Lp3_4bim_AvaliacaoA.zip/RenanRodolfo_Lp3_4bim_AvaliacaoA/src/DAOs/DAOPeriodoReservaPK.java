package DAOs;

import Entidades.PeriodoReserva;

public class DAOPeriodoReservaPK extends DAOGenerico<PeriodoReserva> {

    public DAOPeriodoReservaPK() {
        super(PeriodoReserva.class);
    }
}