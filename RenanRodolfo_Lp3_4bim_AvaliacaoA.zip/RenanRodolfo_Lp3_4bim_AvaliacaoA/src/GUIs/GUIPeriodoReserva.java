////////////GUI////////////
package GUIs;

import DAOs.DAOApartamento;
import DAOs.DAOPeriodoReserva;
import DAOs.DAOPeriodoReservaPK;
import DAOs.DAOReserva;
import Entidades.Acomodacao;
import Entidades.PeriodoReserva;
import Entidades.PeriodoReservaPK;
import Entidades.Reserva;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.table.DefaultTableModel;
import tools.ManipulaArquivo;

import tools.DateTextField;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.SwingConstants;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import tools.Centraliza;
import tools.JanelaPesquisar;

public class GUIPeriodoReserva extends JFrame {

    private Container cp;

    private JLabel lbDataReserva = new JLabel("Número de dias: ",SwingConstants.CENTER);
    private JLabel lbApartamentoIdApartameto = new JLabel("Id da Acomodação: ",SwingConstants.CENTER);
    private JLabel lbReservaIdReserva = new JLabel("Id da Reserva: ",SwingConstants.CENTER);

    private JTextField tfDataReserva = new JTextField(50);
    private JTextField tfApartamentoIdApartameto = new JTextField(50);
    private JTextField tfReservaIdReserva = new JTextField(50);

    private JButton btAdicionar = new JButton("Adicionar");
    private JButton btListar = new JButton("Listar");
    private JButton btBuscar = new JButton("Buscar");
    private JButton btAlterar = new JButton("Alterar");
    private JButton btExcluir = new JButton("Excluir");
    private JButton btSalvar = new JButton("Salvar");
    private JButton btCancelar = new JButton("Cancelar");
    private JButton btCarregarDados = new JButton("Carregar");
    private JButton btGravar = new JButton("Gravar");
    private JToolBar toolBar = new JToolBar();
    private JPanel painelNorte = new JPanel();
    private JPanel painelCentro = new JPanel();
    private JPanel painelSul = new JPanel();
    private JTextArea texto = new JTextArea();
    private JScrollPane scrollTexto = new JScrollPane();
    private JScrollPane scrollTabela = new JScrollPane();

    private String acao = "";
    private String chavePrimaria = "";
    Color corPadraoR = lbReservaIdReserva.getBackground();
    Color corPadraoAP = lbApartamentoIdApartameto.getBackground();

    private DAOPeriodoReserva controle = new DAOPeriodoReserva();
    private DAOPeriodoReservaPK controlePK = new DAOPeriodoReservaPK();
    private PeriodoReserva entidade = new PeriodoReserva();
    private PeriodoReservaPK entidadePK = new PeriodoReservaPK();
    private Acomodacao idAcomodacao = new Acomodacao();
    private Reserva idReserva = new Reserva();
    private DAOApartamento daoApartamento = new DAOApartamento();
    private DAOReserva daoReserva = new DAOReserva();

    String[] colunas = new String[]{"Número de diárias", "Id da Acomodação", "Id da Reserva"};
    String[][] dados = new String[0][3];
    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    private JPanel painel1 = new JPanel(new GridLayout(1, 1));
    private JPanel painel2 = new JPanel(new GridLayout(1, 1));
    private CardLayout cardLayout;
    private JDialog jdialog;

    public GUIPeriodoReserva(JFrame pai) {

        jdialog = new JDialog(pai, "Período das Reservas", true);
        jdialog.getContentPane();
        jdialog.pack();
        jdialog.setTitle("Período das Reservas");
        jdialog.setSize(600, 400);
        jdialog.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        jdialog.setLayout(new GridLayout(1, 1));
        Centraliza centraliza = new Centraliza();
        centraliza.centralizaFilho(pai, jdialog);

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        setSize(600, 300);
        setTitle("CRUD Canguru - V6a");
        setLocationRelativeTo(null);//centro do monitor

        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        cp.add(painelNorte, BorderLayout.NORTH);
        cp.add(painelCentro, BorderLayout.CENTER);
        cp.add(painelSul, BorderLayout.SOUTH);

        cardLayout = new CardLayout();
        painelSul.setLayout(cardLayout);

        painel1.add(scrollTexto);
        painel2.add(scrollTabela);

        texto.setText("\n\n\n\n\n\n");//5 linhas de tamanho
        scrollTexto.setViewportView(texto);

        painelSul.add(painel1, "Avisos");
        painelSul.add(painel2, "Listagem");
        tabela.setEnabled(false);

        painelNorte.setLayout(new GridLayout(1, 1));
        painelNorte.add(toolBar);

        painelCentro.setLayout(new GridLayout(2, 2));

        painelCentro.add(lbApartamentoIdApartameto);
        painelCentro.add(tfApartamentoIdApartameto);
        painelCentro.add(lbReservaIdReserva);
        painelCentro.add(tfReservaIdReserva);

        toolBar.add(lbDataReserva);
        toolBar.add(tfDataReserva);
        toolBar.add(btAdicionar);
        toolBar.add(btBuscar);
        toolBar.add(btListar);
        toolBar.add(btAlterar);
        toolBar.add(btExcluir);
        toolBar.add(btSalvar);
        toolBar.add(btCancelar);

        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btSalvar.setVisible(false);
        btCancelar.setVisible(false);

        tfApartamentoIdApartameto.setEditable(false);
        tfReservaIdReserva.setEditable(false);
        texto.setEditable(false);
        jdialog.add(cp);

        btBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btAdicionar.setVisible(false);

                cardLayout.show(painelSul, "Avisos");
                scrollTexto.setViewportView(texto);
                if (tfDataReserva.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(cp, "Número de dias nâo pode ser vazio");
                    tfDataReserva.requestFocus();
                    tfDataReserva.selectAll();
                } else {
                    chavePrimaria = tfDataReserva.getText();//para uso no adicionar
                    entidadePK.setDataReserva(Integer.valueOf(tfDataReserva.getText()));
                    entidade = controle.obter(entidadePK);
                    if (entidade == null) {//nao encontrou
                        btAdicionar.setVisible(true);
                        btAlterar.setVisible(false);
                        btExcluir.setVisible(false);
                        tfApartamentoIdApartameto.setText("");
                        tfReservaIdReserva.setText("");
                        texto.setText("Não encontrou na lista - pode Adicionar\n\n\n");//limpa o campo texto

                    } else {//encontrou
                        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                        tfApartamentoIdApartameto.setText(Integer.toString(entidade.getPeriodoReservaPK().getApartamentoIdApartamento()));
                        tfReservaIdReserva.setText(Integer.toString(entidade.getPeriodoReservaPK().getReservaIdReserva()));

                        btAlterar.setVisible(true);
                        btExcluir.setVisible(true);
                        texto.setText("Encontrou na lista - pode Alterar ou Excluir\n\n\n");//limpa o campo texto

                        tfApartamentoIdApartameto.setEditable(false);
                        tfReservaIdReserva.setEditable(false);
                    }
                }
            }
        });
        btAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                acao = "adicionar";
                tfDataReserva.setText(chavePrimaria);//para retornar ao valor original (caso o usuário mude e tente enganar o programa)
                tfDataReserva.setEditable(false);
                tfApartamentoIdApartameto.requestFocus();
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btListar.setVisible(false);
                btAlterar.setVisible(false);
                btExcluir.setVisible(false);

                btAdicionar.setVisible(false);
                texto.setText("Preencha os atributos\n\n\n\n\n");//limpa o campo texto
                tfApartamentoIdApartameto.setEditable(true);
                tfReservaIdReserva.setEditable(true);
            }
        });

        btAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                acao = "alterar";
                tfDataReserva.setText(chavePrimaria);//para retornar ao valor original (caso o usuário mude e tente enganar o programa)
                tfDataReserva.setEditable(false);
                tfApartamentoIdApartameto.requestFocus();
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btListar.setVisible(false);
                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                texto.setText("Preencha os atributos\n\n\n\n\n");//limpa o campo texto
                tfApartamentoIdApartameto.setEditable(true);
                tfReservaIdReserva.setEditable(true);
            }
        });

        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                tfDataReserva.setEditable(true);

                tfApartamentoIdApartameto.setText("");
                tfReservaIdReserva.setText("");

                tfDataReserva.requestFocus();
                tfDataReserva.selectAll();
                texto.setText("Cancelou\n\n\n\n\n");//limpa o campo texto

                tfApartamentoIdApartameto.setEditable(false);
                tfReservaIdReserva.setEditable(false);
            }
        });

        btSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (acao.equals("alterar")) {
                    PeriodoReserva entidadeAntigo = entidade;
                    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                    SimpleDateFormat sdfEua = new SimpleDateFormat("yyyy-MM-dd");

                    entidadePK.setApartamentoIdApartamento(Integer.valueOf(tfApartamentoIdApartameto.getText().split("-")[0]));
                    entidadePK.setReservaIdReserva(Integer.valueOf(tfReservaIdReserva.getText().split("-")[0]));
                    entidade.setPeriodoReservaPK(entidadePK);

                    controle.atualizar(entidade);
                    texto.setText("Registro alterado\n\n\n\n\n");//limpa o campo texto
                } else {//adicionar
                    entidade = new PeriodoReserva();
                    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                    SimpleDateFormat sdfEua = new SimpleDateFormat("yyyy-MM-dd");

                    entidadePK.setDataReserva(Integer.valueOf(tfDataReserva.getText()));
                    entidadePK.setApartamentoIdApartamento(Integer.valueOf(tfApartamentoIdApartameto.getText().split("-")[0]));
                    entidadePK.setReservaIdReserva(Integer.valueOf(tfReservaIdReserva.getText().split("-")[0]));
                    entidade.setPeriodoReservaPK(entidadePK);

                    controle.inserir(entidade);
                    texto.setText("Foi adicionado um novo registro\n\n\n\n\n");//limpa o campo texto
                }
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                tfDataReserva.setEditable(true);

                tfApartamentoIdApartameto.setText("");
                tfReservaIdReserva.setText("");

                tfDataReserva.requestFocus();
                tfDataReserva.selectAll();

                tfApartamentoIdApartameto.setEditable(false);
                tfReservaIdReserva.setEditable(false);
            }
        });

        btExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfDataReserva.setText(chavePrimaria);//para retornar ao valor original (caso o usuário mude e tente enganar o programa)
                if (JOptionPane.YES_OPTION
                        == JOptionPane.showConfirmDialog(null,
                                "Confirma a exclusão do registro <ApartamentoIdApartameto = " + entidade.getPeriodoReservaPK().getApartamentoIdApartamento() + ">?", "Confirm",
                                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)) {
                    controle.remover(entidade);
                }
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                tfDataReserva.setEditable(true);

                tfApartamentoIdApartameto.setText("");
                tfReservaIdReserva.setText("");

                tfDataReserva.requestFocus();
                tfDataReserva.selectAll();
                btExcluir.setVisible(false);
                btAlterar.setVisible(false);
                texto.setText("Excluiu o registro de " + entidade.getPeriodoReservaPK().getDataReserva() + " - " + entidade.getPeriodoReservaPK().getApartamentoIdApartamento() + "\n\n\n\n\n");//limpa o campo texto
            }
        });
        btListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<PeriodoReserva> lt = controle.list();

                String[] colunas = {"Número de diárias", "Id da Acomodação", "Id da Reserva"};
                Object[][] dados = new Object[lt.size()][colunas.length];              
                String aux[];
                for (int i = 0; i < lt.size(); i++) {
                    aux = lt.get(i).toString().split(";");
                    for (int j = 0; j < colunas.length; j++) {                       
                        dados[i][j] = aux[j];                      
                    }
                }
                cardLayout.show(painelSul, "Listagem");
                scrollTabela.setPreferredSize(tabela.getPreferredSize());
                painel2.add(scrollTabela);
                scrollTabela.setViewportView(tabela);
                model.setDataVector(dados, colunas);
                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                btAdicionar.setVisible(false);
            }
        });
        tfApartamentoIdApartameto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> listaAuxiliar = daoApartamento.listInOrderNomeStrings("id");
                if (listaAuxiliar.size() > 0) {
                    String selectedItem = new JanelaPesquisar(listaAuxiliar,
                            getBounds().x - getWidth() / 2 + getWidth() + 5,
                            tfApartamentoIdApartameto.getBounds().y + tfApartamentoIdApartameto.getHeight()).getValorRetornado();
                    if (!selectedItem.equals("")) {
                        String[] aux = selectedItem.split("-");
                        tfApartamentoIdApartameto.setText(selectedItem);
                        idAcomodacao = daoApartamento.obter(Integer.valueOf(aux[0]));

                    } else {
                        tfApartamentoIdApartameto.requestFocus();
                        tfApartamentoIdApartameto.selectAll();
                    }
                } else {
                    JOptionPane.showMessageDialog(cp, "Não há nenhum produto cadastrado.");
                }
            }
        });

        tfApartamentoIdApartameto.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                tfApartamentoIdApartameto.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                tfApartamentoIdApartameto.setBackground(corPadraoAP);

            }
        });
        
        tfReservaIdReserva.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> listaAuxiliar = daoReserva.listInOrderNomeStrings("id");
                if (listaAuxiliar.size() > 0) {
                    String selectedItem = new JanelaPesquisar(listaAuxiliar,
                            getBounds().x - getWidth() / 2 + getWidth() + 5,
                            tfReservaIdReserva.getBounds().y + tfReservaIdReserva.getHeight()).getValorRetornado();
                    if (!selectedItem.equals("")) {
                        String[] aux = selectedItem.split("-");
                        tfReservaIdReserva.setText(selectedItem);
                        idReserva = daoReserva.obter(Integer.valueOf(aux[0]));

                    } else {
                        tfReservaIdReserva.requestFocus();
                        tfReservaIdReserva.selectAll();
                    }
                } else {
                    JOptionPane.showMessageDialog(cp, "Não há nenhum produto cadastrado.");
                }
            }
        });

        tfReservaIdReserva.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                tfReservaIdReserva.setBackground(Color.GREEN);
            }

            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                tfReservaIdReserva.setBackground(corPadraoR);

            }
        });
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                //antes de sair, salvar a lista em disco
                // Sai da classe
                dispose();
            }
        });
        jdialog.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                jdialog.dispose();
            }
        });
        jdialog.setVisible(true);
    }
}
