////////////GUI////////////
package GUIs;

import DAOs.DAOReserva;
import DAOs.DAOCliente;
import Entidades.Reserva;
import Entidades.Cliente;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.table.DefaultTableModel;
import tools.ManipulaArquivo;

import tools.DateTextField;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.SwingConstants;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import tools.Centraliza;
import tools.JanelaPesquisar;

public class GUIReserva extends JDialog {

    private Container cp;

    private JLabel lbID = new JLabel("Id: ",SwingConstants.CENTER);
    private JLabel lbData = new JLabel("Reserva: ",SwingConstants.CENTER);
    private JLabel lbIDCliente = new JLabel("Cliente: ",SwingConstants.CENTER);

    private JTextField tfID = new JTextField(50);
    private JTextField tfData = new JTextField(50);
    private JTextField tfIdCliente = new JTextField(50);
    
    DAOReserva daoReserva = new DAOReserva();
    DAOCliente daoCliente = new DAOCliente();

    private JButton btAdicionar = new JButton("Adicionar");
    private JButton btListar = new JButton("Listar");
    private JButton btBuscar = new JButton("Buscar");
    private JButton btAlterar = new JButton("Alterar");
    private JButton btExcluir = new JButton("Excluir");
    private JButton btSalvar = new JButton("Salvar");
    private JButton btCancelar = new JButton("Cancelar");
    private JButton btCarregarDados = new JButton("Carregar");
    private JButton btGravar = new JButton("Gravar");
    private JToolBar toolBar = new JToolBar();
    private JPanel painelNorte = new JPanel();
    private JPanel painelCentro = new JPanel();
    private JPanel painelSul = new JPanel();
    private JTextArea texto = new JTextArea();
    private JScrollPane scrollTexto = new JScrollPane();
    private JScrollPane scrollTabela = new JScrollPane();
    Color corPadrao = lbID.getBackground();

    private String acao = "";
    private String chavePrimaria = "";

    private DAOReserva controle = new DAOReserva();
    private Reserva entidade = new Reserva();
    Cliente tipoacomodacao = new Cliente();


    String[] colunas = {"Id", "Reserva para","Id do Cliente"};
    String[][] dados = new String[0][3];
    DefaultTableModel model = new DefaultTableModel(dados, colunas);
    JTable tabela = new JTable(model);

    private JPanel painel1 = new JPanel(new GridLayout(1, 1));
    private JPanel painel2 = new JPanel(new GridLayout(1, 1));
    private CardLayout cardLayout;
    private JDialog jdialog;

    public GUIReserva(JFrame pai) {

        jdialog = new JDialog(pai, "Reservas", true);
        jdialog.getContentPane();
        jdialog.pack();
        jdialog.setTitle("Reservas");
        jdialog.setSize(800, 400);
        jdialog.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        jdialog.setLayout(new GridLayout(1, 1));
        Centraliza centraliza = new Centraliza();
        centraliza.centralizaFilho(pai, jdialog);

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        setSize(600, 300);

        setLocationRelativeTo(null);//centro do monitor

        cp = getContentPane();
        cp.setLayout(new BorderLayout());
        cp.add(painelNorte, BorderLayout.NORTH);
        cp.add(painelCentro, BorderLayout.CENTER);
        cp.add(painelSul, BorderLayout.SOUTH);

        cardLayout = new CardLayout();
        painelSul.setLayout(cardLayout);

        painel1.add(scrollTexto);
        painel2.add(scrollTabela);

        texto.setText("\n\n\n\n\n\n");//5 linhas de tamanho
        scrollTexto.setViewportView(texto);

        painelSul.add(painel1, "Avisos");
        painelSul.add(painel2, "Listagem");
        tabela.setEnabled(false);

        painelNorte.setLayout(new GridLayout(1, 1));
        painelNorte.add(toolBar);

        painelCentro.setLayout(new GridLayout(2, 2));

        painelCentro.add(lbData);
        painelCentro.add(tfData);
        painelCentro.add(lbIDCliente);
        painelCentro.add(tfIdCliente);

        toolBar.add(lbID);
        toolBar.add(tfID);
        toolBar.add(btAdicionar);
        toolBar.add(btBuscar);
        toolBar.add(btListar);
        toolBar.add(btAlterar);
        toolBar.add(btExcluir);
        toolBar.add(btSalvar);
        toolBar.add(btCancelar);

        btAdicionar.setVisible(false);
        btAlterar.setVisible(false);
        btExcluir.setVisible(false);
        btSalvar.setVisible(false);
        btCancelar.setVisible(false);

        tfData.setEditable(false);
        tfIdCliente.setEditable(false);
        texto.setEditable(false);
        tfData.setText("");
        jdialog.add(cp);
        

        btBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btAdicionar.setVisible(false);

                cardLayout.show(painelSul, "Avisos");
                scrollTexto.setViewportView(texto);
                if (tfID.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(cp, "ID nâo pode ser vazio");
                    tfID.requestFocus();
                    tfID.selectAll();
                } else {
                    chavePrimaria = tfID.getText();//para uso no adicionar
                    entidade = controle.obter(Integer.valueOf(tfID.getText()));
                    if (entidade == null) {//nao encontrou
                        btAdicionar.setVisible(true);
                        btAlterar.setVisible(false);
                        btExcluir.setVisible(false);
                        tfData.setText("");
                        tfIdCliente.setText("");
                        texto.setText("Não encontrou na lista - pode Adicionar\n\n\n");//limpa o campo texto

                    } else {//encontrou
                        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                        tfData.setText(formato.format(entidade.getDataReserva()));
                        tfIdCliente.setText(String.valueOf(entidade.getClientePessoaIdPessoa().getPessoaIdPessoa()+ "-" + entidade.getClientePessoaIdPessoa().getPessoa().getNomePessoa()));
                        btAlterar.setVisible(true);
                        btExcluir.setVisible(true);
                        texto.setText("Encontrou na lista - pode Alterar ou Excluir\n\n\n");//limpa o campo texto

                        tfData.setEditable(false);
                        tfIdCliente.setEditable(false);
                    }
                }
            }
        });
        btAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                acao = "adicionar";
                tfID.setText(chavePrimaria);//para retornar ao valor original (caso o usuário mude e tente enganar o programa)
                tfID.setEditable(false);
                tfData.requestFocus();
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btListar.setVisible(false);
                btAlterar.setVisible(false);
                btExcluir.setVisible(false);

                btAdicionar.setVisible(false);
                texto.setText("Preencha os atributos\n\n\n\n\n");//limpa o campo texto
                tfData.setEditable(true);
                tfIdCliente.setEditable(true);
            }
        });

        btAlterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                acao = "alterar";
                tfID.setText(chavePrimaria);//para retornar ao valor original (caso o usuário mude e tente enganar o programa)
                tfID.setEditable(false);
                tfData.requestFocus();
                btSalvar.setVisible(true);
                btCancelar.setVisible(true);
                btBuscar.setVisible(false);
                btListar.setVisible(false);
                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                texto.setText("Preencha os atributos\n\n\n\n\n");//limpa o campo texto
                tfData.setEditable(true);
                tfIdCliente.setEditable(true);
            }
        });

        btCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                tfID.setEditable(true);

                tfData.setText("");
                tfIdCliente.setText("");

                tfID.requestFocus();
                tfID.selectAll();
                texto.setText("Cancelou\n\n\n\n\n");//limpa o campo texto

                tfData.setEditable(false);
                tfIdCliente.setEditable(false);
            }
        });

        btSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean erro = false;
                if (acao.equals("alterar")) {
                    Reserva entidadeAntigo = entidade;
                    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                    SimpleDateFormat sdfEua = new SimpleDateFormat("yyyy-MM-dd");

                    try {
                        entidade.setDataReserva(Date.valueOf(sdfEua.format(formato.parse(tfData.getText()))));
                        tfData.setForeground(Color.BLACK);
                    } catch (Exception err) {
                        System.out.println("Erro: " + err);
                        tfData.setForeground(Color.RED);
                        erro = true;
                    }
                    entidade.setClientePessoaIdPessoa(daoCliente.obter(Integer.valueOf(tfIdCliente.getText().split("-")[0])));
                    entidade.setIdReserva(Integer.valueOf(tfID.getText()));

                    controle.atualizar(entidade);
                    texto.setText("Registro alterado\n\n\n\n\n");//limpa o campo texto
                } else {//adicionar
                    entidade = new Reserva();
                    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                    SimpleDateFormat sdfEua = new SimpleDateFormat("yyyy-MM-dd");
                    
                    try {
                        entidade.setDataReserva(Date.valueOf(sdfEua.format(formato.parse(tfData.getText()))));
                        tfData.setForeground(Color.BLACK);
                    } catch (Exception err) {
                        System.out.println("Erro: " + err);
                        tfData.setForeground(Color.RED);
                        erro = true;
                    }

                    entidade.setIdReserva(Integer.valueOf(tfID.getText()));
                    entidade.setClientePessoaIdPessoa(daoCliente.obter(Integer.valueOf(tfIdCliente.getText().split("-")[0])));
                    

                    controle.inserir(entidade);
                    texto.setText("Foi adicionado um novo registro\n\n\n\n\n");//limpa o campo texto
                }
                btSalvar.setVisible(false);
                btCancelar.setVisible(false);
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                tfID.setEditable(true);

                tfData.setText("");
                tfIdCliente.setText("");

                tfID.requestFocus();
                tfID.selectAll();

                tfData.setEditable(false);
                tfIdCliente.setEditable(false);
            }
        });

        btExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tfID.setText(chavePrimaria);//para retornar ao valor original (caso o usuário mude e tente enganar o programa)
                if (JOptionPane.YES_OPTION
                        == JOptionPane.showConfirmDialog(null,
                                "Confirma a exclusão do registro <NomeAcomodação = " + entidade.getClientePessoaIdPessoa()+ ">?", "Confirm",
                                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)) {
                    controle.remover(entidade);
                }
                btBuscar.setVisible(true);
                btListar.setVisible(true);
                tfID.setEditable(true);

                tfData.setText("");
                tfIdCliente.setText("");

                tfID.requestFocus();
                tfID.selectAll();
                btExcluir.setVisible(false);
                btAlterar.setVisible(false);
                texto.setText("Excluiu o registro de " + entidade.getIdReserva()+ " - " + entidade.getClientePessoaIdPessoa()+ "\n\n\n\n\n");//limpa o campo texto
            }
        });
        btListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Reserva> lt = controle.list();

                String[] colunas = {"Id", "Reserva para","Id do Cliente"};
                Object[][] dados = new Object[lt.size()][colunas.length];
                String aux[];
                for (int i = 0; i < lt.size(); i++) {
                    aux = lt.get(i).toString().split(";");
                    for (int j = 0; j < colunas.length; j++) {
                        dados[i][j] = aux[j];
                    }
                }
                cardLayout.show(painelSul, "Listagem");
                scrollTabela.setPreferredSize(tabela.getPreferredSize());
                painel2.add(scrollTabela);
                scrollTabela.setViewportView(tabela);
                model.setDataVector(dados, colunas);
                btAlterar.setVisible(false);
                btExcluir.setVisible(false);
                btAdicionar.setVisible(false);
            }
        });
        
        
        tfIdCliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> listaAuxiliar = daoCliente.listInOrderNomeStrings("id");
                if (listaAuxiliar.size() > 0) {
                    String selectedItem = new JanelaPesquisar(listaAuxiliar, 
                         getBounds().x - getWidth() / 2 + getWidth() + 5,
                            tfIdCliente.getBounds().y + tfIdCliente.getHeight()).getValorRetornado();
                    if (!selectedItem.equals("")) {
                        String[] aux = selectedItem.split("-");
                        tfIdCliente.setText(selectedItem);

//                        //preparar para salvar
//                        System.out.println(Integer.valueOf(aux[0]));
                        tipoacomodacao = daoCliente.obter(Integer.valueOf(aux[0]));

                    } else {
                        tfIdCliente.requestFocus();
                        tfIdCliente.selectAll();
                    }
                } else {
                    JOptionPane.showMessageDialog(cp, "Não há nenhum produto cadastrado.");
                }
            }
        });
           
                tfIdCliente.addFocusListener(new FocusListener() { //ao receber o foco, fica verde
            @Override
            public void focusGained(FocusEvent fe) {
                tfIdCliente.setBackground(Color.GREEN);
            }
                            @Override
            public void focusLost(FocusEvent fe) { //ao perder o foco, fica branco
                tfIdCliente.setBackground(corPadrao);
            
        }});
                
                
                

        
        
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                //antes de sair, salvar a lista em disco
                // Sai da classe
                dispose();
            }
        });
        jdialog.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                jdialog.dispose();

            }
        });

        jdialog.setVisible(true);

//depois que a tela ficou visível, clic o botão automaticamente.
    }

}
